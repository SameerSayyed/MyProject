package com.app.pojo;

import java.io.Serializable;

import javax.persistence.*;


/*The persistent class for the T_DISEASE_FORMS database table. */
@Entity
@Table(name="T_DISEASE_FORMS")
//@NamedQuery(name="DiseaseForm.findAll", query="SELECT d FROM DiseaseForm d")
public class DiseaseForm implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer formId;
	private String diseaseDescription;
	private Patient patient;
	private Doctor doctor;
	//private int patientId;
	private String reportFilepath;
	private DiseaseCatagory diseaseCatagory;
	private String status;

	public DiseaseForm() {
	}
	
	

	public DiseaseForm(String diseaseDescription, Patient patient,
			Doctor doctor, String reportFilepath,
			DiseaseCatagory diseaseCatagory)
	{
		super();
		this.diseaseDescription = diseaseDescription;
		this.patient = patient;
		this.doctor = doctor;
		this.reportFilepath = reportFilepath;
		this.diseaseCatagory = diseaseCatagory;
	}



	public DiseaseForm(Integer formId, String diseaseDescription,
			Patient patient, Doctor doctor, String reportFilepath,
			DiseaseCatagory diseaseCatagory)
	{
		super();
		this.formId = formId;
		this.diseaseDescription = diseaseDescription;
		this.patient = patient;
		this.doctor = doctor;
		this.reportFilepath = reportFilepath;
		this.diseaseCatagory = diseaseCatagory;
	}



	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_DISEASE_FORMS_SEQ")
	@SequenceGenerator(name="T_DISEASE_FORMS_SEQ",sequenceName="T_DISEASE_FORMS_SEQ")
	@Column(name="FORM_ID")
	public Integer getFormId() {
		return this.formId;
	}

	public void setFormId(Integer formId) {
		this.formId = formId;
	}


	@Column(name="DISEASE_DESCRIPTION")
	public String getDiseaseDescription() {
		return this.diseaseDescription;
	}

	public void setDiseaseDescription(String diseaseDescription) {
		this.diseaseDescription = diseaseDescription;
	}

	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="PATIENT_ID")
	public Patient getPatient() 
	{
		return this.patient;
	}

	public void setPatient(Patient patient) 
	{
		this.patient = patient;
	}


	@Column(name="REPORT_FILEPATH")
	public String getReportFilepath()
	{
		return this.reportFilepath;
	}

	public void setReportFilepath(String reportFilepath)
	{
		this.reportFilepath = reportFilepath;
	}


	//uni-directional many-to-one association to DiseaseCatagory
	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="DISEASE_ID")
	public DiseaseCatagory getDiseaseCatagory()
	{
		return this.diseaseCatagory;
	}

	public void setDiseaseCatagory(DiseaseCatagory diseaseCatagory) 
	{
		this.diseaseCatagory = diseaseCatagory;
	}

	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="DOCTOR_ID")
	public Doctor getDoctor()
	{
		return doctor;
	}


	public void setDoctor(Doctor doctor)
	{
		this.doctor = doctor;
	}


	@Override
	public String toString()
	{
		return "DiseaseForm [formId=" + formId + ", diseaseDescription="
				+ diseaseDescription + ", patient=" + patient + ", doctor="
				+ doctor + ", reportFilepath=" + reportFilepath
				+ ", diseaseCatagory=" + diseaseCatagory + "]";
	}



	public String getStatus()
	{
		return status;
	}



	public void setStatus(String status)
	{
		this.status = status;
	}
	
	
	
}