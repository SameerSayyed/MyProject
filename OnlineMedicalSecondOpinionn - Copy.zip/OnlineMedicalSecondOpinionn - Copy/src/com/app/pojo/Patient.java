package com.app.pojo;

import java.io.Serializable;

import javax.persistence.*;

import java.util.Date;


/* The persistent class for the T_PATIENT_DETAILS database table. */
@Entity
@Table(name="T_PATIENT_DETAILS")
//@NamedQuery(name="PatientDetail.findAll", query="SELECT p FROM PatientDetail p")
public class Patient implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer patientId;
	private String address;
	private String city;
	private String country;
	private Date dateOfBirth;
	private String firstName;
	private String gender;
	private String lastName;
	private String phone;
	private String pincode;
	private String state;
	private String status;
	private Login login;

	public Patient() {
	}
	

	public Patient(String address, String city, String country,
			Date dateOfBirth, String firstName, String gender, String lastName,
			String phone, String pincode, String state, Login login)
	{
		super();
		this.address = address;
		this.city = city;
		this.country = country;
		this.dateOfBirth = dateOfBirth;
		this.firstName = firstName;
		this.gender = gender;
		this.lastName = lastName;
		this.phone = phone;
		this.pincode = pincode;
		this.state = state;
		this.login = login;
	}


	public Patient(Integer patientId, String address, String city,
			String country, Date dateOfBirth, String firstName, String gender,
			String lastName, String phone, String pincode, String state,
			Login login)
	{
		super();
		this.patientId = patientId;
		this.address = address;
		this.city = city;
		this.country = country;
		this.dateOfBirth = dateOfBirth;
		this.firstName = firstName;
		this.gender = gender;
		this.lastName = lastName;
		this.phone = phone;
		this.pincode = pincode;
		this.state = state;
		this.login = login;
	}


	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_PATIENT_DETAILS_SEQ")
	@SequenceGenerator(name="T_PATIENT_DETAILS_SEQ",sequenceName="T_PATIENT_DETAILS_SEQ")
	@Column(name="PATIENT_ID")
	public Integer getPatientId() {
		return this.patientId;
	}

	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}


	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}


	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}


	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}


	@Temporal(TemporalType.DATE)
	@Column(name="DATE_OF_BIRTH")
	public Date getDateOfBirth() {
		return this.dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}


	@Column(name="FIRST_NAME")
	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}


	@Column(name="LAST_NAME")
	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getPincode() {
		return this.pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}


	@Column(name="\"STATE\"")
	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}


	//uni-directional many-to-one association to Login
	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="LOGIN_ID")
	public Login getLogin() {
		return this.login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}

	public String getStatus()
	{
		return status;
	}


	public void setStatus(String status)
	{
		this.status = status;
	}

	@Override
	public String toString()
	{
		return "Patient [patientId=" + patientId + ", address=" + address
				+ ", city=" + city + ", country=" + country + ", dateOfBirth="
				+ dateOfBirth + ", firstName=" + firstName + ", gender="
				+ gender + ", lastName=" + lastName + ", phone=" + phone
				+ ", pincode=" + pincode + ", state=" + state + ", login="
				+ login + "]";
	}


}