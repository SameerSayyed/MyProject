package com.app.pojo;

import java.io.Serializable;

import javax.persistence.*;


/* The persistent class for the T_DISEASE_CATAGORIES database table. */
@Entity
@Table(name="T_DISEASE_CATAGORIES")
//@NamedQuery(name="DiseaseCatagory.findAll", query="SELECT d FROM DiseaseCatagory d")
public class DiseaseCatagory implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer diseaseId;
	private String catagoryName;

	public DiseaseCatagory() {
	}
	

	public DiseaseCatagory(String catagoryName)
	{
		super();
		this.catagoryName = catagoryName;
	}


	public DiseaseCatagory(Integer diseaseId, String catagoryName)
	{
		super();
		this.diseaseId = diseaseId;
		this.catagoryName = catagoryName;
	}


	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_DISEASE_CATAGORIES_SEQ")
	@SequenceGenerator(name="T_DISEASE_CATAGORIES_SEQ",sequenceName="T_DISEASE_CATAGORIES_SEQ")
	@Column(name="DISEASE_ID")
	public Integer getDiseaseId() {
		return this.diseaseId;
	}

	public void setDiseaseId(Integer diseaseId) {
		this.diseaseId = diseaseId;
	}


	@Column(name="CATAGORY_NAME")
	public String getCatagoryName() {
		return this.catagoryName;
	}

	public void setCatagoryName(String catagoryName) {
		this.catagoryName = catagoryName;
	}


	@Override
	public String toString()
	{
		return "DiseaseCatagory [diseaseId=" + diseaseId + ", catagoryName="
				+ catagoryName + "]";
	}
	
	
}