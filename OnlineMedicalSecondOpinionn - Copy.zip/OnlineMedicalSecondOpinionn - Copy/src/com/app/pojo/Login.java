package com.app.pojo;

import java.io.Serializable;

import javax.persistence.*;


/*The persistent class for the T_LOGIN database table. */
@Entity
@Table(name="T_LOGIN")
//@NamedQuery(name="Login.findAll", query="SELECT l FROM Login l")
public class Login implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer loginId;
	private String email;
	private String password;
	private String role;

	public Login() {
	}
	

	public Login(String email, String password, String role)
	{
		super();
		this.email = email;
		this.password = password;
		this.role = role;
	}


	public Login(Integer loginId, String email, String password, String role)
	{
		super();
		this.loginId = loginId;
		this.email = email;
		this.password = password;
		this.role = role;
	}


	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LOGIN_ID")
	public Integer getLoginId() {
		return this.loginId;
	}

	public void setLoginId(Integer loginId) {
		this.loginId = loginId;
	}


	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}


	@Column(name="\"ROLE\"")
	public String getRole() {
		return this.role;
	}

	public void setRole(String role) {
		this.role = role;
	}


	@Override
	public String toString()
	{
		return "Login [loginId=" + loginId + ", email=" + email + ", password="
				+ password + ", role=" + role + "]";
	}
	
}