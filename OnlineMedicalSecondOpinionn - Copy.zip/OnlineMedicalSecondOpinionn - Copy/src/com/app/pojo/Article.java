package com.app.pojo;

import java.io.Serializable;

import javax.persistence.*;

@Entity
@Table(name="T_ARTICLE")
//@NamedQuery(name="Article.findAll", query="SELECT a FROM Article a")
public class Article implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer articleId;
	private String articleFilepath;
	private String articleTitle;
	private Doctor doctor;
	private int likes;
	private DiseaseCatagory diseaseCatagory;
	private String articleContent;

	public Article() {
	}
	

	public Article(String articleFilepath, String articleTitle, Doctor doctor,
			int likes, DiseaseCatagory diseaseCatagory)
	{
		super();
		this.articleFilepath = articleFilepath;
		this.articleTitle = articleTitle;
		this.doctor = doctor;
		this.likes = likes;
		this.diseaseCatagory = diseaseCatagory;
	}


	public Article(Integer articleId, String articleFilepath,
			String articleTitle, Doctor doctor, int likes,
			DiseaseCatagory diseaseCatagory)
	{
		super();
		this.articleId = articleId;
		this.articleFilepath = articleFilepath;
		this.articleTitle = articleTitle;
		this.doctor = doctor;
		this.likes = likes;
		this.diseaseCatagory = diseaseCatagory;
	}


	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_ARTICLE_SEQ")
	@SequenceGenerator(name="T_ARTICLE_SEQ",sequenceName="T_ARTICLE_SEQ")
	@Column(name="ARTICLE_ID")
	public Integer getArticleId() {
		return this.articleId;
	}

	public void setArticleId(Integer articleId) {
		this.articleId = articleId;
	}


	@Column(name="ARTICLE_FILEPATH")
	public String getArticleFilepath() {
		return this.articleFilepath;
	}

	public void setArticleFilepath(String articleFilepath) {
		this.articleFilepath = articleFilepath;
	}


	@Column(name="ARTICLE_TITLE")
	public String getArticleTitle() {
		return this.articleTitle;
	}

	public void setArticleTitle(String articleTitle) {
		this.articleTitle = articleTitle;
	}

	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="DOCTOR_ID")
	public Doctor getDoctor() {
		return this.doctor;
	}

	public void setDoctor(Doctor doctor) {
		this.doctor = doctor;
	}


	public int getLikes() {
		return this.likes;
	}

	public void setLikes(int likes) {
		this.likes = likes;
	}


	//uni-directional many-to-one association to DiseaseCatagory
	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="DISEASE_ID")
	public DiseaseCatagory getDiseaseCatagory() {
		return this.diseaseCatagory;
	}

	public void setDiseaseCatagory(DiseaseCatagory diseaseCatagory) {
		this.diseaseCatagory = diseaseCatagory;
	}


	@Override
	public String toString()
	{
		return "Article [articleId=" + articleId + ", articleFilepath="
				+ articleFilepath + ", articleTitle=" + articleTitle
				+ ", doctor=" + doctor + ", likes=" + likes
				+ ", diseaseCatagory=" + diseaseCatagory + "]";
	}


	public String getArticleContent()
	{
		return articleContent;
	}


	public void setArticleContent(String articleContent)
	{
		this.articleContent = articleContent;
	}
	
	
}