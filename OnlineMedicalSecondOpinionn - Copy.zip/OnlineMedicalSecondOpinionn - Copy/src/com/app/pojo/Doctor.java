package com.app.pojo;

import java.io.Serializable;

import javax.persistence.*;


/* The persistent class for the T_DOCTOR_DETAILS database table. */
@Entity
@Table(name="T_DOCTOR_DETAILS")
//@NamedQuery(name="DoctorDetail.findAll", query="SELECT d FROM DoctorDetail d")
public class Doctor implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer doctorId;
	private String aboutMe;
	private String address;
	private String city;
	private String country;
	private String firstName;
	private String gender;
	private String lastName;
	private String phone;
	private String pincode;
	private String specialization;
	private String state;
	private String status;
	private Login login;

	public Doctor() {
	}
	

	public Doctor(String aboutMe, String address, String city,
			String country, String firstName, String gender, String lastName,
			String phone, String pincode, String specialization, String state,
			Login login)
	{
		super();
		this.aboutMe = aboutMe;
		this.address = address;
		this.city = city;
		this.country = country;
		this.firstName = firstName;
		this.gender = gender;
		this.lastName = lastName;
		this.phone = phone;
		this.pincode = pincode;
		this.specialization = specialization;
		this.state = state;
		this.login = login;
	}


	public Doctor(Integer doctorId, String aboutMe, String address,
			String city, String country, String firstName, String gender,
			String lastName, String phone, String pincode,
			String specialization, String state, Login login)
	{
		super();
		this.doctorId = doctorId;
		this.aboutMe = aboutMe;
		this.address = address;
		this.city = city;
		this.country = country;
		this.firstName = firstName;
		this.gender = gender;
		this.lastName = lastName;
		this.phone = phone;
		this.pincode = pincode;
		this.specialization = specialization;
		this.state = state;
		this.login = login;
	}


	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "T_DOCTOR_DETAILS_SEQ1")
	@SequenceGenerator(name="T_DOCTOR_DETAILS_SEQ1", sequenceName="T_DOCTOR_DETAILS_SEQ1")
	@Column(name="DOCTOR_ID")
	public Integer getDoctorId() {
		return this.doctorId;
	}

	public void setDoctorId(Integer doctorId) {
		this.doctorId = doctorId;
	}


	@Column(name="ABOUT_ME")
	public String getAboutMe() {
		return this.aboutMe;
	}

	public void setAboutMe(String aboutMe) {
		this.aboutMe = aboutMe;
	}


	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}


	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}


	public String getCountry() {
		return this.country;
	}

	public void setCountry(String country) {
		this.country = country;
	}


	@Column(name="FIRST_NAME")
	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getGender() {
		return this.gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}


	@Column(name="LAST_NAME")
	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}


	public String getPincode() {
		return this.pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}


	public String getSpecialization() {
		return this.specialization;
	}

	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}


	@Column(name="\"STATE\"")
	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}


	//uni-directional many-to-one association to Login
	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="LOGIN_ID")
	public Login getLogin() {
		return this.login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}

	public String getStatus()
	{
		return status;
	}


	public void setStatus(String status)
	{
		this.status = status;
	}

	@Override
	public String toString()
	{
		return "DoctorDetail [doctorId=" + doctorId + ", aboutMe=" + aboutMe
				+ ", address=" + address + ", city=" + city + ", country="
				+ country + ", firstName=" + firstName + ", gender=" + gender
				+ ", lastName=" + lastName + ", phone=" + phone + ", pincode="
				+ pincode + ", specialization=" + specialization + ", state="
				+ state + ", login=" + login + "]";
	}


	
	
}