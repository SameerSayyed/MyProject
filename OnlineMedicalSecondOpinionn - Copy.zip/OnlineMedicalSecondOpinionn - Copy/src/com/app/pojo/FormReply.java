package com.app.pojo;

import java.io.Serializable;

import javax.persistence.*;


/*The persistent class for the T_FORM_REPLY database table. */
@Entity
@Table(name="T_FORM_REPLY")
//@NamedQuery(name="FormReply.findAll", query="SELECT f FROM FormReply f")
public class FormReply implements Serializable {
	private static final long serialVersionUID = 1L;
	private Integer replyId;
	private String doctorFeedback;
	private DiseaseForm diseaseForm;

	public FormReply() {
	}
	

	public FormReply(String doctorFeedback,
			DiseaseForm diseaseForm)
	{
		super();
		this.doctorFeedback = doctorFeedback;
		this.diseaseForm = diseaseForm;
	}


	public FormReply(Integer replyId, String doctorFeedback, 
			DiseaseForm diseaseForm)
	{
		super();
		this.replyId = replyId;
		this.doctorFeedback = doctorFeedback;
		this.diseaseForm = diseaseForm;
	}


	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_DISEASE_FORMS_SEQ")
	@SequenceGenerator(name="T_DISEASE_FORMS_SEQ",sequenceName="T_DISEASE_FORMS_SEQ")
	@Column(name="REPLY_ID")
	public Integer getReplyId() {
		return this.replyId;
	}

	public void setReplyId(Integer replyId) {
		this.replyId = replyId;
	}


	@Column(name="DOCTOR_FEEDBACK")
	public String getDoctorFeedback() {
		return this.doctorFeedback;
	}

	public void setDoctorFeedback(String doctorFeedback) {
		this.doctorFeedback = doctorFeedback;
	}


	//uni-directional many-to-one association to DiseaseForm
	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="FORM_ID")
	public DiseaseForm getDiseaseForm() {
		return this.diseaseForm;
	}

	public void setDiseaseForm(DiseaseForm diseaseForm) {
		this.diseaseForm = diseaseForm;
	}


	@Override
	public String toString()
	{
		return "FormReply [replyId=" + replyId + ", doctorFeedback="
				+ doctorFeedback +  ", diseaseForm="
				+ diseaseForm + "]";
	}
	
}