package com.app.pojo;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


@Entity
@Table(name="T_DELETE_REQUEST")
public class DeleteRequest implements Serializable
{
	private static final long serialVersionUID = 1L;
	private Integer deleteId;
	private Login login;
	private String status;
	
	public DeleteRequest()
	{	}

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="T_DELETE_REQUEST_SEQ")
	@SequenceGenerator(name="T_DELETE_REQUEST_SEQ",sequenceName="T_DELETE_REQUEST_SEQ")
	@Column(name="DELETE_ID")
	public Integer getDeleteId()
	{
		return deleteId;
	}

	public void setDeleteId(Integer deleteId)
	{
		this.deleteId = deleteId;
	}
	
	public DeleteRequest(Login login, String status)
	{
		super();
		this.login = login;
		this.status = status;
	}

	public DeleteRequest(Integer deleteId, Login login, String status)
	{
		super();
		this.deleteId = deleteId;
		this.login = login;
		this.status = status;
	}

	//uni-directional many-to-one association to Login
	@ManyToOne(cascade={CascadeType.ALL})
	@JoinColumn(name="LOGIN_ID")
	public Login getLogin()
	{
		return login;
	}

	public void setLogin(Login login)
	{
		this.login = login;
	}

	@Column(name="STATUS")
	public String getStatus()
	{
		return status;
	}

	public void setStatus(String status)
	{
		this.status = status;
	}

	@Override
	public String toString()
	{
		return "DeleteRequest [deleteId=" + deleteId + ", login=" + login
				+ ", status=" + status + "]";
	}
	
	
}
