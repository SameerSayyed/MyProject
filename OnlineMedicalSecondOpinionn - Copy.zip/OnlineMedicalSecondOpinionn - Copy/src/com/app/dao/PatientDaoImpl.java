package com.app.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojo.Article;
import com.app.pojo.DeleteRequest;
import com.app.pojo.DiseaseCatagory;
import com.app.pojo.DiseaseForm;
import com.app.pojo.Doctor;
import com.app.pojo.FormReply;
import com.app.pojo.Patient;
@Repository
public class PatientDaoImpl implements PatientDao
{
	@Autowired
	private SessionFactory factory;
	
	@Override
	public Integer registerPatient(Patient patien)
	{
		return (Integer)  factory.getCurrentSession().save(patien);
	}

	@Override
	public Patient updatePatient(Patient patient)
	{
		return (Patient)factory.getCurrentSession().merge(patient);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DiseaseCatagory> getCatagoryList()
	{
		return (List<DiseaseCatagory>) factory.getCurrentSession().createQuery("select d from DiseaseCatagory d").list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Doctor> getDoctorList(String catagory)
	{
		return (List<Doctor>) factory.getCurrentSession().createQuery("select d from Doctor d where d.specialization = :sp and d.status = :stat").setParameter("sp", catagory).setParameter("stat", "Active").list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Article> getAllArticles()
	{
		return (List<Article>) factory.getCurrentSession().createQuery("select a from Article a").list();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Article> getArticlesByCatagory(DiseaseCatagory catagory)
	{
		return (List<Article>) factory.getCurrentSession().createQuery("select a from Article a where a.diseaseCatagory = :cat").setParameter("cat", catagory).list();
	}

	@Override
	public DeleteRequest accountDeleteRequest(DeleteRequest deleteRequest)
	{
		Session session = factory.getCurrentSession();
		DeleteRequest request = (DeleteRequest) session.createQuery("select d from DeleteRequest d where d.login = :log").setParameter("log", deleteRequest.getLogin()).uniqueResult();
		if(request != null)
		{
			return deleteRequest;
		}
		session.saveOrUpdate(deleteRequest);
		return deleteRequest;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<FormReply> getAllReplies(Patient patient)
	{
		Session session = factory.getCurrentSession();
		return session.createQuery("select f from FormReply f where f.diseaseForm.patient = :pat").setParameter("pat", patient).list();
		//return null;
	}

	
	@Override
	public void uploadDiseaseForm(DiseaseForm form)
	{	
		System.out.println("form in dao" + form);
		factory.getCurrentSession().save(form);
	}
	
	
	
}
