package com.app.dao;

import java.util.List;

import com.app.pojo.Article;
import com.app.pojo.DeleteRequest;
import com.app.pojo.DiseaseCatagory;
import com.app.pojo.DiseaseForm;
import com.app.pojo.Doctor;
import com.app.pojo.FormReply;
import com.app.pojo.Patient;

public interface PatientDao
{
	Integer registerPatient(Patient patien);
	Patient updatePatient(Patient patient);
	List<DiseaseCatagory> getCatagoryList(); 
	List<Doctor> getDoctorList(String catagory);
	List<Article> getAllArticles();
	List<Article> getArticlesByCatagory(DiseaseCatagory catagory);
	DeleteRequest accountDeleteRequest(DeleteRequest deleteRequest);
	List<FormReply> getAllReplies(Patient patient);
	void uploadDiseaseForm(DiseaseForm form);
}
