package com.app.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojo.Article;
import com.app.pojo.DeleteRequest;
import com.app.pojo.DiseaseCatagory;
import com.app.pojo.DiseaseForm;
import com.app.pojo.Doctor;
import com.app.pojo.FormReply;

@Repository
public class DoctorDaoImpl implements DoctorDao
{
	@Autowired
	SessionFactory factory;
	
	@Override
	public Integer registerDoctor(Doctor doctor)
	{
		return (Integer) factory.getCurrentSession().save(doctor);
	}

	@Override
	public Doctor updateDoctor(Doctor doctor)
	{
		return (Doctor) factory.getCurrentSession().merge(doctor);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public List<DiseaseCatagory> getCatagoryList()
	{
		return (List<DiseaseCatagory>) factory.getCurrentSession().createQuery("select d from DiseaseCatagory d").list();
	}

	@Override
	public Article registerArticle(Article article)
	{
		Session session = factory.getCurrentSession();
		//serializing article object into T_ARTICLE table with a dummy filepath
		Integer id = (Integer)session.save(article);
		//creating a new filepath with unique name i.e. by appending T_ARTICLE's ARTICLE_ID and .dat(Binary File)
		article.setArticleFilepath(article.getArticleFilepath() + id + ".dat");
		//update same record
		article = (Article)session.merge(article);
		
		return article;
	}
	
	@Override
	public DeleteRequest accountDeleteRequest(DeleteRequest deleteRequest)
	{
		Session session = factory.getCurrentSession();
		DeleteRequest request = (DeleteRequest) session.createQuery("select d from DeleteRequest d where d.login = :log").setParameter("log", deleteRequest.getLogin()).uniqueResult();
		if(request != null)
		{
			return deleteRequest;
		}
		session.saveOrUpdate(deleteRequest);
		return deleteRequest;
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<DiseaseForm> getAllDiseaseForms(Doctor doctor)
	{	
		return (List<DiseaseForm>)factory.getCurrentSession().createQuery("select f from DiseaseForm f where f.doctor = :doc and f.status = 'Pending'").setParameter("doc", doctor).list();
	}

	@Override
	public Integer saveReply(FormReply reply)
	{
		Integer id = (Integer) factory.getCurrentSession().save(reply);
		if(id != null)
			return id;
		return null;
	}
	
}
