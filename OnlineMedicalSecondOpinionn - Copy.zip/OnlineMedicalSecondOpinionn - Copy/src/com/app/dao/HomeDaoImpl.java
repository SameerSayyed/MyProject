package com.app.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojo.Doctor;
import com.app.pojo.Login;
import com.app.pojo.Patient;

@Repository
public class HomeDaoImpl implements HomeDao
{
	
	@Autowired
	private SessionFactory factory;
	
	@Override
	public Object validateLogin(Login login)
	{
		Session session = factory.openSession();
		
		try
		{
		Login log = (Login) session.createQuery("select l from Login l where email = :eml and password = :pass").setParameter("eml", login.getEmail()).setParameter("pass", login.getPassword()).uniqueResult();
				
		if(log != null)
		{
			if(log.getRole().equalsIgnoreCase("P"))
			{
				
				return(Patient) session.createQuery("select p from Patient p where login = :log").setParameter("log", log).uniqueResult();
			}
			return (Doctor) session.createQuery("select d from Doctor d where login = :log").setParameter("log", log).uniqueResult();
		}
		}
		finally
		{
			session.close();
		}
		return null;
	}

}
