package com.app.dao;

import java.util.List;

import com.app.pojo.Article;
import com.app.pojo.DeleteRequest;
import com.app.pojo.DiseaseCatagory;
import com.app.pojo.DiseaseForm;
import com.app.pojo.Doctor;
import com.app.pojo.FormReply;

public interface DoctorDao
{
	Integer registerDoctor(Doctor doctor);
	Doctor updateDoctor(Doctor doctor);
	List<DiseaseCatagory> getCatagoryList();
	Article registerArticle(Article article);
	DeleteRequest accountDeleteRequest(DeleteRequest deleteRequest);
	List<DiseaseForm> getAllDiseaseForms(Doctor doctor);
	Integer saveReply(FormReply reply);
}
