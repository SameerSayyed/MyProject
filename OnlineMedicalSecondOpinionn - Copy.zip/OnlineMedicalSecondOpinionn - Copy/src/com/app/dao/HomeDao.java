package com.app.dao;

import com.app.pojo.Login;


public interface HomeDao
{
	Object validateLogin(Login login);
	
}
