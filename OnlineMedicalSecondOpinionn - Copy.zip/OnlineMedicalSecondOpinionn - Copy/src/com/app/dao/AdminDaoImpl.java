package com.app.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojo.Admin;
import com.app.pojo.DeleteRequest;
import com.app.pojo.Doctor;
import com.app.pojo.Login;
import com.app.pojo.Patient;

@Repository
public class AdminDaoImpl implements AdminDao
{
	@Autowired
	private SessionFactory factory;
	
	@Override
	public Admin validateAdmin(Admin admin)
	{
		return (Admin) factory.getCurrentSession().createQuery("select a from Admin a where email = :eml and password = :pass").setParameter("eml", admin.getEmail()).setParameter("pass", admin.getPassword()).uniqueResult();
		
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<DeleteRequest> getAllDeletionRequests()
	{
		return (List<DeleteRequest>)factory.getCurrentSession().createQuery("select d from DeleteRequest d where d.status = :stat").setParameter("stat", "Pending").list();
	}

	@Override
	public void deleteRecord(DeleteRequest request)
	{
		Session session =  factory.getCurrentSession();
		session.update(request);
		if(request.getLogin().getRole().equalsIgnoreCase("P"))
		{
			Patient patient = (Patient) session.createQuery("select p from Patient p where p.login = :log").setParameter("log", request.getLogin()).uniqueResult();
			patient.setStatus("Deleted");
			patient.setLogin(new Login(patient.getLogin().getLoginId(), "deleted " + patient.getLogin().getLoginId(), patient.getLogin().getPassword(), "P"));
			patient.setPhone("NA " + patient.getPatientId());
			session.update(patient);
		}
		else
		{
			Doctor doctor = (Doctor) session.createQuery("select d from Doctor d where d.login = :log").setParameter("log", request.getLogin()).uniqueResult();
			doctor.setStatus("Deleted");
			doctor.setLogin(new Login(doctor.getLogin().getLoginId(), "deleted " + doctor.getLogin().getLoginId(), doctor.getLogin().getPassword(), "D"));
			doctor.setPhone("NA " + doctor.getDoctorId());
			session.update(doctor);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Doctor> getAllApproveRequest()
	{
		return (List<Doctor>)factory.getCurrentSession().createQuery("select d from Doctor d where d.status = :stat").setParameter("stat", "Pending").list();
	}

	@Override
	public void approveDoctor(Doctor doctor)
	{
		doctor.setStatus("Active");
		factory.getCurrentSession().update(doctor);
	}

	
	@SuppressWarnings("unchecked")
	@Override
	public List<Doctor> getAllDoctors()
	{
		return factory.getCurrentSession().createQuery("select d from Doctor d").list();
	}

}
