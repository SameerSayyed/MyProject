package com.app.dao;

import java.util.List;

import com.app.pojo.Admin;
import com.app.pojo.DeleteRequest;
import com.app.pojo.Doctor;

public interface AdminDao
{
	Admin validateAdmin(Admin admin);
	List<DeleteRequest> getAllDeletionRequests();
	void deleteRecord(DeleteRequest request);
	List<Doctor> getAllApproveRequest();
	void approveDoctor(Doctor doctor);
	List<Doctor> getAllDoctors();
}
