package com.app.controller;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.app.pojo.Article;
import com.app.pojo.DeleteRequest;
import com.app.pojo.DiseaseCatagory;
import com.app.pojo.DiseaseForm;
import com.app.pojo.Doctor;
import com.app.pojo.FormReply;
import com.app.pojo.Patient;
import com.app.service.PatientService;

@Controller
@RequestMapping("/patient")
public class PatientController
{
	@Autowired
	private PatientService service;
	
	public PatientController()
	{
		System.out.println("In Patient Controller");
	}
	
	@RequestMapping(value = "/home")
	public String showHome()
	{
		return "redirect:home/home";
	}

	@RequestMapping(value = "/homepatient")
	public String showPatientHome(HttpSession session)
	{
		if(session.getAttribute("pat") == null)
			return "redirect:/home/login";
		return "patient/homepatient";
	}
	
	@RequestMapping(value = "/register") 
	public String showRegister(Patient patient)
	{
		System.out.println("In ShowRegister");
		return "patient/patientregister";
	}
		
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String registerPatient(Patient patien, BindingResult result, Model map)
	{
		System.out.println(patien);
		System.out.println("\n" + patien.getLogin().getEmail());
		System.out.println(patien.getLogin().getPassword());

		patien.getLogin().setRole("P");
		Integer id = service.registerPatient(patien);
		if(id != null)
		{
			map.addAttribute("reg", "Successfully Registered With Registration Id : " + id);
			return "patient/registered";
		}
		map.addAttribute("reg", "Has some errors");
		return "patient/patientregister";
	}
	
	@RequestMapping(value="/profile")
	public String showProfile(HttpSession session)
	{
		if(session.getAttribute("pat") == null)
			return "redirect:/home/login";
		return "patient/profile";
	}
	
	@RequestMapping(value="/editProfile")
	public String showEditProfile(Patient patient, HttpSession session)
	{
		if(session.getAttribute("pat") == null)
			return "redirect:/home/login";
		System.out.println("in Edit Profile");
		return "patient/editprofile";
	}
	
	@RequestMapping(value="/editProfile", method = RequestMethod.POST)
	public String processEditProfile(Patient patient, BindingResult result ,HttpSession session, Model map)
	{
		Patient pat = (Patient) session.getAttribute("pat");
		patient.setPatientId(pat.getPatientId());
		patient.setGender(pat.getGender());
		patient.setLogin(pat.getLogin());
		System.out.println("Befor Updating p: " + patient);
		pat = service.updatePatient(patient);
		if(pat !=null )
		{
			session.setAttribute("pat", pat);
			map.addAttribute("profileUpdateStatus", "Profile Is Updated");
			System.out.println("After Updating p: " + pat);
			return "patient/homepatient";
		}
		map.addAttribute("profileUpdateStatus", "Please Fill All Fields Correctly");
		return "patient/editProfile";
	}
	
	@RequestMapping(value = "/secondopinion")
	public String showDiseaseForm(DiseaseForm form, HttpSession session)
	{
		if(session.getAttribute("pat") == null)
			return "redirect:/home/login";
	
		session.setAttribute("show", "DiseaseSelection");
		//System.out.println("In showDiseaseForm");
		List<DiseaseCatagory> catagoryList =  service.getCatagoryList();
		session.setAttribute("catagoris", catagoryList);
		
		return "patient/secondopinion";
	}
	
	@RequestMapping(value="changeCatagory")
	public String changeCatagory(DiseaseForm form, HttpSession session)
	{
		session.setAttribute("show", "DiseaseSelection");
		return "patient/secondopinion";
	}
	
	@RequestMapping(value="changeDoctor")
	public String changeDoctor(DiseaseForm form, HttpSession session)
	{
		session.setAttribute("show", "DoctorSelection");
		return "patient/secondopinion";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/chooseDoctor")
	public String chooseCatagory(DiseaseForm form, HttpSession session)
	{
		session.setAttribute("show", "DoctorSelection");
		System.out.println("In chooseCatagory");
		System.out.println("Catagory populated	:	" + form);
		//HAve Catagory Name
		
		session.setAttribute("catagoryChoosen", form.getDiseaseCatagory().getCatagoryName());
				/*Pupulating DiseaseForm Pojo*/
				List<DiseaseCatagory> catagoryList = (List<DiseaseCatagory>)session.getAttribute("catagoris");
				for (DiseaseCatagory catagory : catagoryList)
				{
					if(catagory.getCatagoryName().equalsIgnoreCase(form.getDiseaseCatagory().getCatagoryName()))
						form.setDiseaseCatagory(catagory);
				}
				session.setAttribute("pupulatedForm", form);
			
		System.out.println( "Catagory Name	:	" + form.getDiseaseCatagory().getCatagoryName());
		List<Doctor> doctorList = service.getDoctorList(form.getDiseaseCatagory().getCatagoryName());
		
		session.setAttribute("doctors", doctorList);
		return "patient/secondopinion";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/showDoctor")
	public String showDoctorDetails(Doctor doctor, HttpSession session)
	{
		if(session.getAttribute("pat") == null)
			return "redirect:/home/login";
		
		session.setAttribute("show", "Description");
		
		System.out.println("In showDoctorDetails");
		 
				/*Pupulating DiseaseForm Pojo*/
				List<Doctor> doctors =(List<Doctor>)session.getAttribute("doctors");
				DiseaseForm form = new DiseaseForm();
				for (Doctor doc : doctors)
				{
					System.out.println("doc: " + doc);
					if(doc.getLogin().getEmail().equals(doctor.getLogin().getEmail()))
					{
						System.out.println("doccccc : " + doc);
						 form = (DiseaseForm)session.getAttribute("pupulatedForm");
						 form.setDoctor(doc);
						 form.setPatient((Patient)session.getAttribute("pat"));
					}
				}
				session.setAttribute("pupulatedForm", form);/*This form pojo has Patient Details, DoctorDetails and DiseaseCatagory*/
				
		System.out.println("choosen Doctor	:	" + form.getDoctor().getFirstName());
		session.setAttribute("doctorChoosen", form.getDoctor().getFirstName());
		
		return "patient/secondopinion";
	}
	 
	@RequestMapping(value = "/showUpload")
	public String showUploadPage(DiseaseForm form, HttpSession session)
	{
		if(session.getAttribute("pat") == null)
			return "redirect:/home/login";
		System.out.println("In showUploadPage");
		DiseaseForm frm = (DiseaseForm) session.getAttribute("pupulatedForm");
		frm.setDiseaseDescription(form.getDiseaseDescription()); 		//Form pojo -  added Description
		session.setAttribute("pupulatedForm", frm);
		return "patient/fileupload";
	}
	
	@Bean(name="multipartResolver")
	CommonsMultipartResolver getMultipartResolver()
	{
		CommonsMultipartResolver cmr= new CommonsMultipartResolver();
		cmr.setMaxUploadSize(20971520);
		cmr.setMaxInMemorySize(1048576);
		return cmr;
	}
	
	@RequestMapping(value = "/processUpload")
	public String processUploadPage(@RequestParam MultipartFile report,DiseaseForm form, HttpSession session, HttpServletRequest req) throws IOException
	{
		System.out.println("in show file");
		System.out.println("File Name "+report.getOriginalFilename());
		form = (DiseaseForm) session.getAttribute("pupulatedForm");
		
		File dir= new File("C:\\Users\\SAM\\workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp1\\wtpwebapps\\OnlineMedicalSecondOpinion\\PatientReports");
		System.out.println();
		File file= File.createTempFile("SecondOpinion", report.getOriginalFilename(), dir);
		BufferedOutputStream stream= new BufferedOutputStream(new FileOutputStream(file));
		stream.write(report.getBytes());
		System.out.println(dir.getAbsolutePath());
		
		form.setReportFilepath(file.getName());
		System.out.println("Eligible Form Pojo : " + form);
		/*SToring details to database*/
		form.setStatus("Pending");
		service.uploadDiseaseForm(form);
		stream.close();
		req.setAttribute("formsent", "Your Request for Second Opinion is successfully Registered.");
		return "patient/homepatient";
	}
	
	@RequestMapping(value = "article")
	public String showArticle(HttpSession session) 
	{
		if(session.getAttribute("pat") == null)
			return "redirect:/home/login";
		session.setAttribute("show", "all");
		
		List<DiseaseCatagory> catagoryList =  service.getCatagoryList();
		session.setAttribute("catagoris", catagoryList);
		
		System.out.println("in showArticle");
		List<Article> allArticle = service.getAllArticles();
		List<Article> allArticles = new ArrayList<Article>();
		for (Article article : allArticle)
		{
			System.out.println(article);
			article.setArticleContent(DoctorController.readArticleFromFile(article.getArticleFilepath()));
			allArticles.add(article);
		}
		session.setAttribute("allArticles", allArticles);
		return "patient/articles";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/articleCatagory")
	public String showCatgoriwiseArticle(@RequestParam("selectedCatagory") String selectedCatagory,HttpSession session)
	{
		session.setAttribute("show", "specific");
		System.out.println("selectedCatagory name : " + selectedCatagory);
		
				List<Article> sortedArticles = null;
				for (DiseaseCatagory catagor : (List<DiseaseCatagory>) session.getAttribute("catagoris"))
				{
					if(catagor.getCatagoryName().equalsIgnoreCase(selectedCatagory))
					{
						sortedArticles = service.getArticlesByCatagory(catagor);
						session.setAttribute("sortedArticles", sortedArticles);
					}		
				}
				System.out.println("after getArticlesByCatagory");
				sortedArticles = null;
				List<Article> sortedArticless = (List<Article>)session.getAttribute("sortedArticles");
				System.out.println("Status : " + sortedArticless == null);
				for (Article article : sortedArticless)
				{
					System.out.println("sorted Articles List : " + article);
					article.setArticleContent(DoctorController.readArticleFromFile(article.getArticleFilepath()));
					sortedArticless.add(article);
				}
				session.setAttribute("sortedArticles", sortedArticless);
		
		
		for (Article art : (List<Article>)session.getAttribute("sortedArticles"))
		{
			System.out.println("Populated articles : : " + art);
		}
		return "patient/articles";
	}
	
	@RequestMapping(value="/deleteRequest")
	public String showDeleteForm(DeleteRequest deleteRequest, HttpSession session) 
	{
		if(session.getAttribute("pat") == null)
			return "redirect:/home/login";
		return "patient/deleteaccount";
	}
	
	@RequestMapping(value="/deleteRequest",method = RequestMethod.POST)
	public String processDeleteForm(DeleteRequest deleteRequest, HttpSession session)
	{
		if(deleteRequest.getStatus().equalsIgnoreCase("No"))
			return "patient/homepatient";
		Patient patient = (Patient) session.getAttribute("pat");
		deleteRequest.setLogin(patient.getLogin());
		deleteRequest.setStatus("Pending");
		deleteRequest = service.accountDeleteRequest(deleteRequest);
		session.setAttribute("stat", "Your Account  Deletion Request has been registered. Your Account will be deleted soon. Thank you for Beeing With us.");
		System.out.println(deleteRequest);
		return "patient/homepatient";
	}
	
	@RequestMapping(value = "/viewOpenion")
	public String showOpinion(HttpSession session)
	{
		
		if(session.getAttribute("pat") == null)
			return "redirect:/home/login";
		
		List<FormReply> list = service.getAllReplies((Patient)session.getAttribute("pat"));
		if(list.isEmpty())
			session.setAttribute("reply", "No Replies");
		session.setAttribute("formReplies", list);
		return "patient/opinion";
	}
	
	@RequestMapping(value="/logout")
	public String showLogout(HttpSession session, HttpServletRequest request, HttpServletResponse response)
	{	
		if(session.getAttribute("pat") == null)
			return "redirect:/home/login";
		
		session.invalidate();
		return "patient/logout";
	}
}
