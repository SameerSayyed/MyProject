package com.app.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.app.pojo.Admin;
import com.app.pojo.DeleteRequest;
import com.app.pojo.Doctor;
import com.app.service.AdminService;

@Controller
@RequestMapping("/admin")
public class AdminController
{
	@Autowired
	AdminService service;
	
	public AdminController()
	{
		System.out.println("In AdminController Ctor");
	}
	
	@RequestMapping(value = "/home")
	public String showHome(HttpSession session)
	{
		if(session.getAttribute("adm") == null)
			return "admin/loginadmin";
		return "admin/admin";
	}
	
	@RequestMapping(value = "/login")
	public String showAdminLogin(Admin admin, Model map)
	{
		System.out.println("In Show Admin Login");
		return "admin/loginadmin";
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String validateAdmin(Admin admin, BindingResult result , Model map, HttpSession session)
	{
		Admin admin1 =  service.validateAdmin(admin);
		if(admin1 != null )
		{
				session.setAttribute("adm", admin1);
				return "admin/admin";
		}
		map.addAttribute("status", "Email or Password is incorrect");
		return "admin/loginadmin";
	}

	@RequestMapping(value = "deleteRequest")
	public String showAccountDeletionRequests(DeleteRequest deleteRequest,HttpSession session)
	{
		if(session.getAttribute("adm") == null)
			return "redirect:/admin/login";
		
		session.setAttribute("deleteRequests", service.getAllDeletionRequests());
		return "admin/deleterequest";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/delete")
	public String processDeletionRequest(DeleteRequest deleteRequest,HttpSession session)
	{
		
		List<DeleteRequest> requests = (List<DeleteRequest>)session.getAttribute("deleteRequests");
		for (DeleteRequest deleteRequest1 : requests)
		{
			if(deleteRequest1.getLogin().getEmail().equals(deleteRequest.getLogin().getEmail()))
			{	
				deleteRequest1.setStatus("Done");
				service.deleteRecord(deleteRequest1);
			}
		}
		return "redirect:/admin/deleterequest";
	}
	
	@RequestMapping(value = "doctorApprove")
	public String showAccountApproveRequests(Doctor doctor,HttpSession session)
	{
		if(session.getAttribute("adm") == null)
			return "redirect:/admin/login";
		
		session.setAttribute("approveRequests", service.getAllApproveRequest());
		return "admin/doctorapprove";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/approve")
	String processAccountApproveRequests(Doctor doctor, HttpSession session)
	{
		List<Doctor> requests = (List<Doctor>)session.getAttribute("approveRequests");
		for (Doctor doctor1 : requests)
		{
			if(doctor1.getLogin().getEmail().equals(doctor.getLogin().getEmail()))
				service.approveDoctor(doctor1);
		}
		return "redirect:/admin/doctorApprove";
	}
	
	@RequestMapping(value = "/allDoctor")
	public String showAllDoctor(HttpSession session)
	{
		if(session.getAttribute("adm") == null)
			return "redirect:/admin/login";
		
		session.setAttribute("allDoctors", service.getAllDoctors());
		
		return "admin/viewdoctors";
	}
	
	
	@RequestMapping(value = "/logout")
	public String showLogout(HttpSession session)
	{
		if(session.getAttribute("adm") == null)
			return "redirect:/admin/login";
		session.invalidate();
		return "admin/logout";
	}
	
}
