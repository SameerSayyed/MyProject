package com.app.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojo.Article;
import com.app.pojo.DeleteRequest;
import com.app.pojo.DiseaseCatagory;
import com.app.pojo.DiseaseForm;
import com.app.pojo.Doctor;
import com.app.pojo.FormReply;
import com.app.service.DoctorService;

@Controller
@RequestMapping("/doctor")
public class DoctorController
{
	@Autowired
	DoctorService service;
	
	public DoctorController()
	{	
		System.out.println("In DoctorController");
	}
	
	@RequestMapping(value = "/home")
	public String showHome()
	{
		return "redirect:home/home";
	}

	@RequestMapping(value = "/homedoctor")
	public String showDoctorHome(HttpSession session)
	{
		if(session.getAttribute("doc") == null)
			return "redirect:/home/login";
		return "doctor/homedoctor";
	}
	
	@RequestMapping(value = "/register") 
	public String showRegister(Doctor doctor)
	{
		System.out.println("In ShowRegister");
		return "doctor/doctorregister";
	}
		
	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String registerDoctor(Doctor doctor, BindingResult result, Model map)
	{
		doctor.getLogin().setRole("D");
		doctor.setStatus("Pending");
		Integer id = service.registerDoctor(doctor);
		if(id != null)
		{
			map.addAttribute("reg", "Successfully Registered With Registration Id : " + id);
			return "doctor/registered";
		}
		map.addAttribute("reg", "Has some errors");
		return "doctor/doctorregister";
	}
	
	@RequestMapping(value="/profile")
	public String showProfile(HttpSession session)
	{
		if(session.getAttribute("doc") == null)
			return "redirect:/home/login";
		return "doctor/profile";
	}
	
	@RequestMapping(value="/editProfile")
	public String showEditProfile(Doctor doctor, HttpSession session)
	{
		if(session.getAttribute("doc") == null)
			return "redirect:/home/login";
		System.out.println("in Edit Profile");
		return "doctor/editprofile";
	}
	
	@RequestMapping(value="/editProfile", method = RequestMethod.POST)
	public String processEditProfile(Doctor doctor, BindingResult result ,HttpSession session, Model map)
	{
			
		Doctor doc = (Doctor) session.getAttribute("doc");
		doctor.setDoctorId(doc.getDoctorId());
		doctor.setGender(doc.getGender());
		doctor.setLogin(doc.getLogin());
		doctor.setSpecialization(doc.getSpecialization());
		doctor.setStatus("Active");
		doc = service.updateDoctor(doctor);
		if(doc !=null )
		{
			session.setAttribute("doc", doc);
			map.addAttribute("profileUpdateStatus", "Profile Is Updated");
			System.out.println("After Updating d: " + doc);
			return "doctor/homedoctor";
		}
		map.addAttribute("profileUpdateStatus", "Please Fill All Fields Correctly");
		return "doctor/editprofile";
	}
	
	@RequestMapping(value = "article")
	public String showArticleForm(Article article,HttpSession session)
	{
		if(session.getAttribute("doc") == null)
			return "redirect:/home/login";
		
		return "doctor/articleupload";
	}
	
	@RequestMapping(value="article", method= RequestMethod.POST)
	public String processArticleForm(Article article, @RequestParam("article") String articleContent, HttpSession session)
	{
				/*Getting Disease for which this article is being Posted*/
				Doctor doctor = (Doctor)session.getAttribute("doc");
				List<DiseaseCatagory> diseaseCatList = service.getCatagoryList();
				for (DiseaseCatagory disease : diseaseCatList)
				{
					if(disease.getCatagoryName().equalsIgnoreCase(doctor.getSpecialization()))
						article.setDiseaseCatagory(disease);
				}
				//Adding doctor details who is posting this article
				article.setDoctor(doctor);
		
		
		System.out.println(article);
		 
		String path = "F:\\ProjectFiles\\Articles\\articlefile";
		article.setArticleFilepath(path);
		article = service.registerArticle(article);
		System.out.println("after storing to db : : : : : : " + article);
		
		String filepath = article.getArticleFilepath();
		
		if(DoctorController.writeArticleToFile(articleContent,filepath))
			System.out.println("written Article into file");
		//System.out.println(DoctorController.readArticleFromFile(filepath));
		session.setAttribute("articlePost", "Article Posted Successfully");
		return "doctor/homedoctor";
	}
	
	public static boolean writeArticleToFile(String articleContent, String filepath)
	{	
		try(ObjectOutputStream stream = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(new File(filepath))));)
		{
			stream.writeObject(articleContent);
		}catch (Exception e)
		{	e.printStackTrace();	return false;	}
		return true;
	}
	
	public static String readArticleFromFile(String filepath)
	{
		try(ObjectInputStream stream = new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File(filepath))));)
		{
			return (String)stream.readObject();
		}catch (Exception e) {	e.printStackTrace();	}
		return "nahi na zal";
	}
	
	@RequestMapping(value="/deleteRequest")
	public String showDeleteForm(DeleteRequest deleteRequest, HttpSession session) 
	{
		if(session.getAttribute("doc") == null)
			return "redirect:/home/login";
		return "doctor/deleteaccount";
	}
	
	@RequestMapping(value="/deleteRequest",method = RequestMethod.POST)
	public String processDeleteForm(DeleteRequest deleteRequest, HttpSession session)
	{
		if(deleteRequest.getStatus().equalsIgnoreCase("No"))
			return "doctor/homedoctor";
		Doctor doctor = (Doctor) session.getAttribute("doc");
		deleteRequest.setLogin(doctor.getLogin());
		deleteRequest.setStatus("Pending");
		deleteRequest = service.accountDeleteRequest(deleteRequest);
		session.setAttribute("stat", "Your Account  Deletion Request has been registered. Your Account will be deleted soon. Thank you for Beeing With us.");
		System.out.println(deleteRequest);
		return "doctor/homedoctor";
	}
	
	@RequestMapping(value = "/opinionRequests")
	public String showDiseaseForms(DiseaseForm form ,HttpSession session)
	{
		 List<DiseaseForm> forms = service.getAllDiseaseForms((Doctor)session.getAttribute("doc"));
		
		 session.setAttribute("forms", forms);
		return "doctor/opinionrequests";
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/shwoReuest")
	public String showRequest(DiseaseForm form, HttpSession session, FormReply reply)
	{
		
		List<DiseaseForm> forms = (List<DiseaseForm>)session.getAttribute("forms");
		for (DiseaseForm diseaseForm : forms)
		{
			if(diseaseForm.getPatient().getLogin().getEmail().equals(form.getPatient().getLogin().getEmail()))
			{
				form = diseaseForm;
				session.setAttribute("selectedForm", diseaseForm);
			}
		}
		session.setAttribute("selectedForm", form);
		return "doctor/request";
	}
	
	@RequestMapping(value = "/reply")
	public String processReply(FormReply reply,HttpSession session, HttpServletRequest request)
	{
		DiseaseForm form = (DiseaseForm)session.getAttribute("selectedForm");
		System.out.println("Form : " + form);
		form.setStatus("Done");
		reply.setDiseaseForm(form);
		Integer id =  service.saveReply(reply);
		if(id == null)
			System.out.println("has some problem");
		request.setAttribute("replied", "Your Reply has been sent");
		return "doctor/homedoctor";
	}
	 
	 @RequestMapping(value = "pdf")
	 public String pdfDownload()
	 {
		 return "pdf1";
	 }
	
	@RequestMapping(value="/logout")
	public String showLogout(HttpSession session)
	{	
		if(session.getAttribute("doc") == null)
			return "redirect:/home/login";
		
		session.invalidate();
		return "doctor/logout";
	}
}
