package com.app.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.app.pojo.Doctor;
import com.app.pojo.Login;
import com.app.pojo.Patient;
import com.app.service.HomeService;

@Controller
@RequestMapping("/home")
public class HomeController
{
	@Autowired
	private HomeService service;
	
	public HomeController()
	{
		System.out.println("In HomeController");
	}
	@RequestMapping(value = "/home")
	String showHome()
	{
		return "home";
	}
	
	@RequestMapping(value = "/login")
	public String showLogin(Login login, Model map)
	{
		return "login";
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String validateLogin(Login login, BindingResult result, Model map ,HttpSession session)
	{
		Object object = service.validateLogin(login);
		if(object != null)
		{
			if(object instanceof Patient)
			{
				Patient patient = (Patient) object;
				session.setAttribute("pat", patient);
				System.out.println("P : " + patient);
				return "redirect:/patient/homepatient";
			}
			else
			{
				Doctor doctor = (Doctor) object;
				session.setAttribute("doc", doctor);
				System.out.println("D : " + doctor);
				return "redirect:/doctor/homedoctor";
			}
		}
		map.addAttribute("status", "Invalid Email or Password");
		return "login";
	}
	
/*	
	@RequestMapping(value = "/temp")
	String showTemplate()
	{
		return "tmpl";
	}
	
	//TESTING
	
	@RequestMapping(value = "test")
	public String showTest()
	{
		return "test";
	}
	
	@RequestMapping(value="file")
	String showFile()
	{
		System.out.println("in show file");
		return "file";
	}
	
	@Bean(name="multipartResolver")
	CommonsMultipartResolver getMultipartResolver()
	{
		CommonsMultipartResolver cmr= new CommonsMultipartResolver();
		cmr.setMaxUploadSize(20971520);
		cmr.setMaxInMemorySize(1048576);
		return cmr;
	}
	
	@RequestMapping(value="/upload")
	public String uploadFile(@RequestParam MultipartFile report, HttpServletRequest req) throws IOException
	{
		System.out.println("in show file");
		
		System.out.println("File Name "+report.getOriginalFilename());
	
		File dir= new File("C:\\Users\\SAM\\workspace\\.metadata\\.plugins\\org.eclipse.wst.server.core\\tmp1\\wtpwebapps\\OnlineMedicalSecondOpinion\\PatientReports");
		System.out.println();
		File file= File.createTempFile("SecondOpinion", report.getOriginalFilename(), dir);
		BufferedOutputStream stream= new BufferedOutputStream(new FileOutputStream(file));
		stream.write(report.getBytes());
		
		System.out.println(file.getName());
		
		System.out.println(dir.getAbsolutePath());
		req.setAttribute("imgPath",file.getName());
		stream.close();
		return "file";
	}
	
	@RequestMapping(value = "/pdf")
	public String showpdf()
	{
		return "pdf1";
	}*/
}
