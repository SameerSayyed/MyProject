package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.PatientDao;
import com.app.pojo.Article;
import com.app.pojo.DeleteRequest;
import com.app.pojo.DiseaseCatagory;
import com.app.pojo.DiseaseForm;
import com.app.pojo.Doctor;
import com.app.pojo.FormReply;
import com.app.pojo.Patient;

@Service
@Transactional
public class PatientServiceImpl implements PatientService
{
	@Autowired
	private PatientDao dao;
	
	@Override
	public Integer registerPatient(Patient patien)
	{
		return dao.registerPatient(patien);
	}


	@Override
	public Patient updatePatient(Patient patient)
	{
		return dao.updatePatient(patient);
	}

	@Override
	public List<DiseaseCatagory> getCatagoryList()
	{
		return dao.getCatagoryList();
	}

	@Override
	public List<Doctor> getDoctorList(String catagory)
	{
		return dao.getDoctorList(catagory);
	}


	@Override
	public List<Article> getAllArticles()
	{
		return dao.getAllArticles();
	}


	@Override
	public List<Article> getArticlesByCatagory(DiseaseCatagory catagory)
	{
		return dao.getArticlesByCatagory(catagory);
	}


	@Override
	public DeleteRequest accountDeleteRequest(DeleteRequest deleteRequest)
	{
		return dao.accountDeleteRequest(deleteRequest);
	}


	@Override
	public List<FormReply> getAllReplies(Patient patient)
	{
		return dao.getAllReplies(patient);
	}


	@Override
	public void uploadDiseaseForm(DiseaseForm form)
	{
		dao.uploadDiseaseForm(form);
	}
}
