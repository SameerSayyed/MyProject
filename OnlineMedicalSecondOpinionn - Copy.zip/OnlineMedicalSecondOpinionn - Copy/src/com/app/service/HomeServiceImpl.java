package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.HomeDao;
import com.app.pojo.Login;

@Service
@Transactional
public class HomeServiceImpl implements HomeService
{
	@Autowired
	private HomeDao dao;
	
	@Override
	public Object validateLogin(Login login)
	{
		return dao.validateLogin(login);
	}

}
