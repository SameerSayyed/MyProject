package com.app.service;

import java.util.List;

import com.app.pojo.Admin;
import com.app.pojo.DeleteRequest;
import com.app.pojo.Doctor;

public interface AdminService
{
	 Admin validateAdmin(Admin admin);
	 List<DeleteRequest> getAllDeletionRequests();
	 void deleteRecord(DeleteRequest request);
	 List<Doctor> getAllApproveRequest();
	void approveDoctor(Doctor doctor);
	List<Doctor> getAllDoctors();
}
