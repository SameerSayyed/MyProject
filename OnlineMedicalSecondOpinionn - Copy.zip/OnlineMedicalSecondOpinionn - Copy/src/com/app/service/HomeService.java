package com.app.service;

import com.app.pojo.Login;

public interface HomeService
{
	Object validateLogin(Login login);
	
}
