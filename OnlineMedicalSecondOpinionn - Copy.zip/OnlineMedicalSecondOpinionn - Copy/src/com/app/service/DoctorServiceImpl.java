package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.DoctorDao;
import com.app.pojo.Article;
import com.app.pojo.DeleteRequest;
import com.app.pojo.DiseaseCatagory;
import com.app.pojo.DiseaseForm;
import com.app.pojo.Doctor;
import com.app.pojo.FormReply;

@Service
@Transactional
public class DoctorServiceImpl implements DoctorService
{
	@Autowired
	DoctorDao dao;
		
	@Override
	public Integer registerDoctor(Doctor doctor)
	{
		return dao.registerDoctor(doctor);
	}

	@Override
	public Doctor updateDoctor(Doctor doctor)
	{
		return dao.updateDoctor(doctor);
	}
	
	@Override
	public List<DiseaseCatagory> getCatagoryList()
	{
		return dao.getCatagoryList();
	}

	@Override
	public Article registerArticle(Article article)
	{
		return dao.registerArticle(article);
	}

	@Override
	public DeleteRequest accountDeleteRequest(DeleteRequest deleteRequest)
	{
		return dao.accountDeleteRequest(deleteRequest);
	}

	@Override
	public List<DiseaseForm> getAllDiseaseForms(Doctor doctor)
	{
		return dao.getAllDiseaseForms(doctor);
	}

	@Override
	public Integer saveReply(FormReply reply)
	{
		return dao.saveReply(reply);
	}
	
}
