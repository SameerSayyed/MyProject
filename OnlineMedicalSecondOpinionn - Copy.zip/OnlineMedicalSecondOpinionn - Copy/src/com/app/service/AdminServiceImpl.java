package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.AdminDao;
import com.app.pojo.Admin;
import com.app.pojo.DeleteRequest;
import com.app.pojo.Doctor;

@Service
@Transactional
public class AdminServiceImpl implements AdminService
{
	@Autowired
	AdminDao dao;
	
	@Override
	public Admin validateAdmin(Admin admin)
	{	return dao.validateAdmin(admin);	}
	@Override
	public List<DeleteRequest> getAllDeletionRequests()
	{		return dao.getAllDeletionRequests();	}
	@Override
	public void deleteRecord(DeleteRequest request)
	{		dao.deleteRecord(request);		}
	@Override
	public List<Doctor> getAllApproveRequest()
	{		return dao.getAllApproveRequest();	}
	@Override
	public void approveDoctor(Doctor doctor)
	{		dao.approveDoctor(doctor);	}
	@Override
	public List<Doctor> getAllDoctors()
	{		return dao.getAllDoctors();	}

}
